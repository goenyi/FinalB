/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author estudiante
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String goenyi = ("hola we xd");
       String selvin = ("hoy hay examen de progra");
       String gustavo = ("09/08/2017");
       String shadow = ("y aun la extraño :v");
       String lawea = ("Pero espero salir bien en este examen v:<");
  System.out.println(goenyi + selvin + gustavo + shadow + lawea);
    }
    
}
